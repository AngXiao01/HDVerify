Building all infra images:

```bash
sh infra/base-images/all.sh
```
